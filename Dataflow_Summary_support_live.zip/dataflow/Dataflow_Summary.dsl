parameters{
	dataflow_param_fiscalyear as integer (2020)
}
source(output(
		FiscalYear as integer,
		PayrollNumber as integer,
		AgencyID as string,
		AgencyName as string,
		EmployeeID as string,
		LastName as string,
		FirstName as string,
		AgencyStartDate as date,
		WorkLocationBorough as string,
		TitleCode as string,
		TitleDescription as string,
		LeaveStatusasofJune30 as string,
		BaseSalary as double,
		PayBasis as string,
		RegularHours as double,
		RegularGrossPaid as double,
		OTHours as double,
		TotalOTPaid as double,
		TotalOtherPay as double
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> source1
source(output(
		FiscalYear as integer,
		PayrollNumber as integer,
		AgencyCode as string,
		AgencyName as string,
		EmployeeID as string,
		LastName as string,
		FirstName as string,
		AgencyStartDate as date,
		WorkLocationBorough as string,
		TitleCode as string,
		TitleDescription as string,
		LeaveStatusasofJune30 as string,
		BaseSalary as double,
		PayBasis as string,
		RegularHours as double,
		RegularGrossPaid as double,
		OTHours as double,
		TotalOTPaid as double,
		TotalOtherPay as double
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> source2
source1 union(byName: true)~> selpayroll2020
source2 union(byName: true)~> selpayroll2021
selpayroll2020 select(mapColumn(
		FiscalYear,
		PayrollNumber,
		AgencyID,
		AgencyName,
		EmployeeID,
		LastName,
		FirstName,
		AgencyStartDate,
		WorkLocationBorough,
		TitleCode,
		TitleDescription,
		LeaveStatusasofJune30,
		BaseSalary,
		PayBasis,
		RegularHours,
		RegularGrossPaid,
		OTHours,
		TotalOTPaid,
		TotalOtherPay
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> select1
selpayroll2021 select(mapColumn(
		FiscalYear,
		PayrollNumber,
		AgencyCode,
		AgencyName,
		EmployeeID,
		LastName,
		FirstName,
		AgencyStartDate,
		WorkLocationBorough,
		TitleCode,
		TitleDescription,
		LeaveStatusasofJune30,
		BaseSalary,
		PayBasis,
		RegularHours,
		RegularGrossPaid,
		OTHours,
		TotalOTPaid,
		TotalOtherPay
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> select2
selpayroll2021, selpayroll2020 union(byName: true)~> unionpayroll
unionpayroll filter(toInteger(FiscalYear) >= $dataflow_param_fiscalyear) ~> fltfiscalyear
fltfiscalyear derive(TotalPaid = RegularGrossPaid + TotalOTPaid + TotalOtherPay) ~> drvtotalpaid
drvtotalpaid select(mapColumn(
		AgencyName,
		FiscalYear,
		TotalPaid
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sel_summary_output
sel_summary_output sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		FiscalYear as integer,
		AgencyName as string,
		TotalPaid as double
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	truncate:true,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError') ~> sinksqlsummary
drvtotalpaid sink(allowSchemaDrift: true,
	validateSchema: false,
	truncate: true,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sinkadlsstaging
sel_summary_output sink(allowSchemaDrift: true,
	validateSchema: false,
	truncate: true,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	header: (false())) ~> NYCPayrollSummary